How to Change the Cursor

1. Auto install.inf 파일 우클릭 후 설치 클릭

2. Mouse Size check 바로가기 실행 후 포인터 크기를 2로 조정 ( 안하면 커서 이미지 깨져요 )

3. Mouse setup 실행 후 [포인터 > 구성표] 에서 Zani custom cursor 선택 후 적용 버튼 클릭

ㅡㅡㅡ

1. Right-click the Auto install.inf file and click Install.

2. Run the Mouse Size check shortcut and adjust the pointer size to 2 (If not done, the cursor image may be distorted).

3. Run Mouse Setup, go to [Pointers > Scheme], select Zani custom cursor, and click Apply.